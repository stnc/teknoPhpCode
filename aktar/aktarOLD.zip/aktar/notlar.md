https://rudrastyh.com/wordpress/rest-api-create-delete-posts.html

media upload 
https://stackoverflow.com/questions/59671683/upload-media-to-wordpress-using-rest-api

https://stackoverflow.com/questions/37432114/wp-rest-api-upload-image

http://wp-api.org/node-wpapi/guides/2016/08/15/create-a-post-with-featured-media.html