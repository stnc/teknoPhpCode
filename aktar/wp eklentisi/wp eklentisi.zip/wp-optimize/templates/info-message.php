<?php if (!defined('ABSPATH')) die('No direct access.'); ?>
<div class="wpo_info">
	<?php echo $message; ?>
</div>